"""
intro_to_LMMs: A package for exploring large language models (LMMs).
"""

__version__ = "0.1.0"

def greet():
    """
    A simple function to demonstrate the package functionality.
    """
    return "Welcome to the intro_to_LMMs package!"